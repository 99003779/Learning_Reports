/**
 * @file mystring.h
 * @author Neha Tabassum (neha.tabassum@ltts.com)
 * @brief This file stores header for all the boxes
 * @version 0.1
 * @date 2021-02-23
 * 
 * @copyright Copyright (c) 2021
 * 
 */

# ifndef __BITMASK_H__
# define __BITMASK_H__

int set(int n, int k);
int reset(int n, int k);
int flip(int n, int k);
# endif 