#ifndef __SERVERCLIENT_H
#define __SERVERCLIENT_H

#include<mqueue.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#endif