#ifndef __PIPES_H
#define __PIPES_H

#include<unistd.h>
#include<stdio.h> 
#include<fcntl.h>
#include<string.h> 
#include<stdlib.h> 

#endif