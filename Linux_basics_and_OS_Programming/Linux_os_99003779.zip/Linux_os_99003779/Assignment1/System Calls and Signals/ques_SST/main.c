#include "SendSignal.h"

int main()
{
  childprocess();
}