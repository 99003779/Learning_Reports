#ifndef __MAXMIN_H
#define __MAXMIN_H

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

/* Finding maximum number in Array*/
int findmax();
/* Finding minimum number in Array */
int findmin();

#endif