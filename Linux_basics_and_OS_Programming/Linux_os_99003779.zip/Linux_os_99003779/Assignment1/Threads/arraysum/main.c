#include "sum.h"

int main()
{
  printf("Sum of 1000 random numbers : %d\n", sumof1000()); /* Print the sum of 1000 random numbers */
  return 0;
}