#ifndef __SUM_H
#define __SUM_H

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

/* Function for adding 1000 random numbers */
int sumof1000(); 

#endif