
#ifndef __MINISHELL_H
#define __MINISHELL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

void MiniShell();

#endif