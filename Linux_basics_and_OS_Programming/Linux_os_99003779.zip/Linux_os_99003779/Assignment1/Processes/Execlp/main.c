#include "execlp.h"

int main()
{
  compile();
  return 0;
}